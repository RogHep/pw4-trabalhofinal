export default function App() {
  return (
    <h1 className="text-6xl font-bold text-red-600 p-10">
      Tailwind Funcionando!!!
    </h1>
  );
}
